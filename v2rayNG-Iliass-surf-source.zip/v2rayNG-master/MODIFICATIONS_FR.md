# Iliass-surf — projet Android personnalisé

Thème sombre bleu électrique et section Nous contacter / WhatsApp.

## Compilation

Projet Gradle situé dans `V2rayNG/`. Depuis ce dossier, lancez `./gradlew assembleDebug`. La compilation n’a pas encore été validée dans cet environnement.
